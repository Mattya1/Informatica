struct dyn_array{
    unsigned int *A;
    unsigned int D;
};

bool ascendingSequenceEvenOdd(const int* arr, unsigned int dim);

dyn_array indexOfEvenInArray(const int* arr,unsigned int dim);
