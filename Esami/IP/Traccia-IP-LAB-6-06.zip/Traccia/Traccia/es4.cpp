#include "list.h"

void tailInsert(List &list, Elem newElem)
{

}