#include "list.h"
#include <iostream>

std::string lessFrequentFind(List list)
{
   
    return "change";
}


