unsigned int returnLucasNumberInPos(unsigned int pos);
