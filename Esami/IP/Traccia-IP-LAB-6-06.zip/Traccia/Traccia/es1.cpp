#include "funz.h"

unsigned int returnLucasNumberInPos(unsigned int pos){ 
	
	 return 123;  
}

