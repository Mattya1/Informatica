#include "array.h"

bool ascendingSequenceEvenOdd(const int* arr, unsigned int dim){
	
	return false;
}
