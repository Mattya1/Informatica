#include "list.h"

unsigned int elementIstancesCount(List list, Elem toFind)
{
  
   return 0;
}