#include "array.h"

dyn_array indexOfEvenInArray(const int* arr,unsigned int dim){
  dyn_array ret;
  
  return ret;
}
