#ifndef ANOVA_H
#define ANOVA_H

#include <vector>

class Anova {
public:
    Anova() = default;
    Anova(std::vector < std::vector<double> > arr) {
        element.resize(arr.size());
        for (int i = 0; i < arr.size(); ++i) {
            element[i].resize(arr[i].size());
            for (int j = 0; j < arr[i].size(); ++j) {
                element[i][j] = arr[i][j];
            }
        }
    }
    Anova(const Anova& other) = default;
    Anova& operator=(const Anova& other) = default;

    double Xi(int i)
    {
        double somma = 0.0;
        for (int j = 0; j < element[i].size(); ++j)
            somma += element[i][j];
        return ((1.0 / element[i].size()) * somma);
    }

    double x_punto_punto()
    {
        double somma = 0.0;
        for (int k = 0; k < element.size(); ++k)
            somma += this->Xi(k);
        return (somma / element.size());
    }

    double SSw()
    {
        double somma = 0.0;
        for (int i = 0; i < element.size(); ++i) {
            for (int j = 0; j < element[i].size(); ++j) {
                somma += (((element[i][j] - this->Xi(i))) * ((element[i][j] - this->Xi(i))));
            }
        }
        return somma;
    }

    double SSb()
    {
        double somma = 0.0;
        for (int i = 0; i < element.size(); ++i) {
            somma += ((this->Xi(i) - this->x_punto_punto()) * (this->Xi(i) - this->x_punto_punto()));
        }
        return element[0].size() * somma;
    }

    double Ts()
    {
        return ((this->SSb() / (element.size() - 1)) / (this->SSw() / (element.size() * element[0].size() - element.size())));
    }
    void print() {
        for (int i = 0; i < element.size(); i++) {
            std::cout << "X" << i + 1 << ". = " << this->Xi(i) << std::endl;
        }
        std::cout << "X.. = " << this->x_punto_punto() << std::endl;
        std::cout << "SSw: " << this->SSw() << std::endl;
        std::cout << "SSb: " << this->SSb() << std::endl;
        std::cout << "Ts: " << this->Ts() << std::endl;
    }
private:
    std::vector < std::vector<double> > element;
};

#endif 

