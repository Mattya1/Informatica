#ifndef REGRESSIONLINE_H
#define REGRESSIONLINE_H

#include "Statistics.h"
#include <vector>

class RegressionLine {
public:
    RegressionLine() = default;
    RegressionLine(std::vector<double> A, std::vector<double> B) : A_element(A), B_element(B) {}
    RegressionLine(const RegressionLine& other) = default;
    RegressionLine& operator=(const RegressionLine& other) = default;
    Statistic getA() {
        return A_element;
    }
    Statistic getB() {
        return B_element;
    }
    double Sxy()
    {
        double somma = 0.0;
        for (int i = 0; i < A_element.GetSize(); i++)
            somma += (A_element[i] * B_element[i]);
        return (somma - A_element.GetSize() * A_element.media() * B_element.media());
    }
    double Sxx()
    {
        double somma = 0.0;
        for (int i = 0; i < A_element.GetSize(); i++)
            somma += (A_element[i] * A_element[i]);
        return (somma - A_element.GetSize() * A_element.media() * A_element.media());
    }
    double Syy()
    {
        double somma = 0.0;
        for (int i = 0; i < B_element.GetSize(); i++)
            somma += (B_element[i] * B_element[i]);
        return (somma - B_element.GetSize() * B_element.media() * B_element.media());
    }

    double SSr()
    {
        return (((this->Sxx() * this->Syy()) - this->Sxy() * this->Sxy()) / (this->Sxx()));
    }

    double B()
    {
        return ((this->Sxy()) / (this->Sxx()));
    }

    double A()
    {
        return ((B_element.media()) - (this->B() * A_element.media()));
    }
    void print() {
        std::cout << "x medio: " << this->getA().media() << std::endl;
        std::cout << "Y medio: " << this->getB().media() << std::endl;
        std::cout << "Sxy: " << this->Sxy() << std::endl;
        std::cout << "Sxx: " << this->Sxx() << std::endl;
        std::cout << "Syy: " << this->Syy() << std::endl;
        std::cout << "SSr: " << this->SSr() << std::endl;
        std::cout << "B: " << this->B() << std::endl;
        std::cout << "A: " << this->A() << std::endl;
    }
private:
    Statistic A_element;
    Statistic B_element;
};

#endif
