#ifndef STATISTIC_H
#define STATISTIC_H

#include <vector>
#include <math.h>

class Statistic {
public:
    Statistic() = default;
    Statistic(std::vector<double> s) {
        element.resize(s.size());
        for (int i = 0; i < s.size(); ++i) {
            element[i] = s[i];
        }
    }
    Statistic(const Statistic& other) = default;
    Statistic& operator=(const Statistic& other) = default;
    int GetSize() const {
        return element.size();
    }
    double& operator[](int index) {
        return element[index];
    }
    double media()
    {
        double somma = 0.0;
        for (int i = 0; i < element.size(); ++i) {
            somma += element[i];
        }
        return ((1.0 / element.size()) * (somma));
    }

    double var_gaussiana()
    {
        double somma = 0.0;
        for (int i = 0; i < element.size(); i++)
            somma += ((element[i] - this->media()) * (element[i] - this->media()));
        return (1.0 / element.size()) * somma;
    }

    double var_campionaria()
    {
        double somma = 0.0;
        for (int i = 0; i < element.size(); i++)
            somma += ((element[i] - this->media()) * (element[i] - this->media()));
        return (1.0 / (element.size() - 1)) * somma;
    }
    void print() {
        std::cout << "Media campionaria: " << this->media() << std::endl;
        std::cout << "Stima varianza di una gaussiana: " << this->var_gaussiana() << std::endl;
        std::cout << "Stima deviazione standard di una gaussiana: " << sqrt(this->var_gaussiana()) << std::endl;
        std::cout << "Varianza campionaria: " << this->var_campionaria() << std::endl;
        std::cout << "Deviazione standard campionaria: " << sqrt(this->var_campionaria()) << std::endl;
    }
private:
    std::vector<double> element;
};

#endif