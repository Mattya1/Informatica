#include <iostream>
#include <vector>
#include "RegressionLine.h"
#include "Statistics.h"
#include "Anova.h"

int main()
{
    std::vector<double> D = { 4,9,8,3,1,0.5,1,1.5,2.5 }; //Inserie dati necessari
    Statistic s(D);
    std::cout << "DATI STATISTICI" << std::endl;
    s.print();

    std::vector<double> Y = { 0,0.5,1,1,1.5,2.5,3,4,8,9 }; //Inserie dati necessari
    std::vector<double> x = { 1,2,3,4,5,6,7,8,9,10 }; //Inserie dati necessari
    RegressionLine R(x, Y);
    std::cout << "\nDATI RETTA DI REGRESSIONE" << std::endl;
    R.print();


    std::vector < std::vector<double> > z = { {3.2,3.4,3.3,3.5},{3.4,3.0,3.7,3.3},{2.8,2.6,3.0,2.7} }; //Inserie dati necessari
    Anova a{ z };
    std::cout << "\nDATI ANOVA" << std::endl;
    a.print();
}