#include <string>         // std::string

using namespace std;

void removeBlanksAndLower(string& s);
